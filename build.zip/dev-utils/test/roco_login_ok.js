let uuid = require('../../node_modules/uuid');
module.exports = {
    data: {
        "resource": "/interface-cisat",
        "path": "/interface-cisat",
        "httpMethod": "POST",
        "headers": {
            "Accept": "application/json, text/plain, */*",
            "Authorization": "Bearer bnmu6WzW619tnH7jnmfsv2tAsm8Ddzikoq4u6876",
            "Content-Type": "application/x-www-form-urlencoded",
            "Host": "ki9hpt0c69.execute-api.us-east-1.amazonaws.com",
            "User-Agent": "axios/0.18.0",
            "x-amzn-cipher-suite": "ECDHE-RSA-AES128-GCM-SHA256",
            "x-amzn-vpc-id": "vpc-0f8c6dcb33b1de4c5",
            "x-amzn-vpce-config": "1",
            "x-amzn-vpce-id": "vpce-0bf36175a003fce6f",
            "X-Forwarded-For": "172.19.163.37",
            "X-Request-Id": uuid.v1()
        },
        "multiValueHeaders": {
            "Accept": [
                "application/json, text/plain, */*"
            ],
            "Authorization": [
                "Bearer bnmu6WzW619tnH7jnmfsv2tAsm8Ddzikoq4u6876"
            ],
            "Content-Type": [
                "application/x-www-form-urlencoded"
            ],
            "Host": [
                "ki9hpt0c69.execute-api.us-east-1.amazonaws.com"
            ],
            "User-Agent": [
                "axios/0.18.0"
            ],
            "x-amzn-cipher-suite": [
                "ECDHE-RSA-AES128-GCM-SHA256"
            ],
            "x-amzn-vpc-id": [
                "vpc-0f8c6dcb33b1de4c5"
            ],
            "x-amzn-vpce-config": [
                "1"
            ],
            "x-amzn-vpce-id": [
                "vpce-0bf36175a003fce6f"
            ],
            "X-Forwarded-For": [
                "172.19.163.37"
            ]
        },
        "queryStringParameters": null,
        "multiValueQueryStringParameters": null,
        "pathParameters": null,
        "stageVariables": null,
        "requestContext": {
            "resourceId": "tlq3fj",
            "authorizer": {
                "credentials": "{\"groups\":[\"Authorizer_Admin\"],\"keyId\":\"73EC7E5043890963488280519FD56740278BBB0F645F65D6447AAB2B2176C7D6\",\"roles\":[\"Authorizer_Admin\"],\"userId\":\"Authorizer_Admin\",\"currentStatus\":\"active\",\"tenantId\":\"tenant1\",\"expiration_date_utc\":\"2100/12/31T23:59:59+0000\",\"applicationId\":[\"interface-cisat\"],\"factors\":{\"sourceIp\":{\"NotIpAddress\":\"2.3.3.3/12\",\"IpAddress\":\"190.221.0.0/16\"}},\"usageIdentifierKey\":\"73EC7E5043890963488280519FD56740278BBB0F645F65D6447AAB2B2176C7D6\",\"username\":\"authorizer_admin\",\"tenant\":\"tenant1\"}",
                "principalId": "authorizer_admin",
                "integrationLatency": 0,
                "protocols": "[{\"resource\":\"authorizer_api:/authorizer-apikeys\",\"actions\":[\"POST\"],\"effect\":\"allow\"},{\"resource\":\"authorizer_api:/authorizer-roles\",\"actions\":[\"GET\",\"POST\"],\"effect\":\"allow\"},{\"resource\":\"authorizer_api:/authorizer-users\",\"actions\":[\"GET\",\"POST\"],\"effect\":\"allow\"},{\"resource\":\"circuit_creator:/create-circuit\",\"actions\":[\"POST\"],\"effect\":\"allow\"},{\"resource\":\"circuit_creator:/fill-circuit-tables\",\"actions\":[\"POST\"],\"effect\":\"allow\"},{\"resource\":\"interface-cisat:/interface-cisat\",\"actions\":[\"POST\"],\"effect\":\"allow\"}]"
            },
            "resourcePath": "/interface-cisat",
            "operationName": "interfacecisatPost",
            "httpMethod": "POST",
            "extendedRequestId": "bL0zGHXsIAMFg4w=",
            "requestTime": "12/Jun/2019:21:01:07 +0000",
            "path": "/dtkdev/interface-cisat",
            "accountId": "104455529394",
            "protocol": "HTTP/1.1",
            "stage": "dtkdev",
            "domainPrefix": "ki9hpt0c69",
            "requestTimeEpoch": 1560373267825,
            "requestId": "32f64e7f-8d55-11e9-8562-ed792aac3d6d",
            "identity": {
                "cognitoIdentityPoolId": null,
                "cognitoIdentityId": null,
                "vpceId": "vpce-0bf36175a003fce6f",
                "principalOrgId": null,
                "cognitoAuthenticationType": null,
                "userArn": null,
                "userAgent": "axios/0.18.0",
                "accountId": null,
                "caller": null,
                "sourceIp": "172.19.163.37",
                "accessKey": null,
                "vpcId": "vpc-0f8c6dcb33b1de4c5",
                "cognitoAuthenticationProvider": null,
                "user": null
            },
            "domainName": "ki9hpt0c69.execute-api.us-east-1.amazonaws.com",
            "apiId": "ki9hpt0c69"
        },
        "body": "{\"userId\":\"rbenal@gmail.com\",\"password\":\"123456789\"}",
        "isBase64Encoded": false
    }
};

